This is FUNNIE, the Functional Networked Integrated Environment.  See http://funnie.sourceforge.net/ for details.

To run, you should be able to just double-click on the jar file.  It requires an up-to-date (version 5.0) Java runtime.
It will reference the ANTLR library from the lib directory, so it should stay in the same relative location to the jar.